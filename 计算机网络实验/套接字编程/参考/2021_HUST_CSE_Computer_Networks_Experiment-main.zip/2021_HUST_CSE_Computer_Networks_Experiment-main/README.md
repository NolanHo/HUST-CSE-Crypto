# 2021_HUST_CSE_Computer_Networks_Experiment
2021华科网安计网实验

实验一 socket编程

   vs2019
 
   只放了源码和可执行程序
 
   参考自 Agent——Guo学长
 
实验二 实物组网试验

   很简单的
  
实验三 模拟校园网组网

   参考自ssddl
  
 
