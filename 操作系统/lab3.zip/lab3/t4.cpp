#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <sys/types.h>
#include <iostream>
using namespace std;

#define UL unsigned long
#define U64 uint64_t

char buf[100];
const int a = 20;

void getAddressInfo(char* str, UL pid, UL viraddress, UL* phyaddress)
{
    U64 temp = 0;
    int pageSize = getpagesize();
    UL vir_pageIndex = viraddress / pageSize; // 虚拟页号
    UL vir_offset = vir_pageIndex * sizeof(U64); // pagemap文件中的偏移量
    UL page_offset = viraddress % pageSize; // 虚拟地址在页面中的偏移量

    sprintf(buf, "%s%lu%s", "/proc/", pid, "/pagemap");

    int fd = open(buf, O_RDONLY); // 只读打开
    lseek(fd, vir_offset, SEEK_SET); // 游标移动
    read(fd, &temp, sizeof(U64)); // 读取对应项的值

    U64 phy_pageIndex = (((U64)1 << 55) - 1) & temp; // 物理页号
    *phyaddress = (phy_pageIndex * pageSize) + page_offset; // 加页内偏移量得物理地址

    printf("[%s]\tpid=%lu\n", str, pid);
    printf("Virtual address = 0x%lx\n", viraddress);
    printf("Page Number= %lu\n", vir_pageIndex);
    printf("Physical Page Frame Number = %lu\n", phy_pageIndex);
    printf("physical Address = 0x%lx\n", *phyaddress);
    printf("\n");
    return;
}

UL phy = 4;
int main()
{
    int b = 1;
    const int d = 3;
    int pid = fork();

    getAddressInfo("int b", getpid(), (UL)&b, &phy);

    getAddressInfo("const int d", getpid(), (UL)&d, &phy);

    getAddressInfo("Global UL phy = 4", getpid(), (UL)&a, &phy);

    return 0;
}
