g++ t1-1.cpp -o t1-1
g++ t1-2.cpp -o t1-2

g++ t2-LRU.cpp -o t2-LRU

g++ t2-OPT.cpp -o t2-OPT

# 不输出warning
g++ t4.cpp -o t4 -w 