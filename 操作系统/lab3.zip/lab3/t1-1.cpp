#include<bits/stdc++.h>
#include<time.h>

using namespace std;
#define N 10240
int MyArray[N][2*N];


int main() {
    auto startTime = clock();
    for(int i = 0;i < N;i++)
        for(int j = 0;j < 2*N;j++) {
            MyArray[i][j] = 0;
        }

    auto endTime = clock();
    cout << "Time: " << (double)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;
    return 0;
}
