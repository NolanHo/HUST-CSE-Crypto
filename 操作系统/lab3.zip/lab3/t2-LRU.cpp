﻿#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cstdlib>
#include <cstring>
#include <stack>
#include <map>

using namespace std;

const int pageSize = 16;	//页面大小
const int instrCnt = pageSize * 150;		//指令数目
const int pageFrameCnt = 5;		//页框数

int orderCnt;		//访问次数
int cnt = 0;	//当前页框数
int pageMissCnt = 0;	//缺页数
int processArr[instrCnt];		//进程数组
int pageFrame[pageFrameCnt][pageSize];
int orderArr[100];			//访问序列
int pageIdx[pageFrameCnt];	//页框中存的页号

//访问序列
const int requestOrder[] = {
	456,499,45,2002,2001,2002,119,112,113,455,2001,600,601,
	89,119,489,490,499,489,1000,1101,89,119,489,114,115,
	1100,1101,1102,2189,2002,210
};

void LRU();
void initInstrOrder(const int* srcArr = nullptr, int size = 0);
void copyFromTo(int pfIdx, int pageNo);
void showPageFrame();

int main() {
	srand(time(nullptr));

	// 初始化进程数组
	for (int i = 0; i < instrCnt; ++i) {
		processArr[i] = rand() % 1000;
	}
	initInstrOrder(requestOrder, sizeof(requestOrder) / sizeof(int));

	cout << "[Page]\tRequest Order:\n";
	for (int i = 0; i < orderCnt; ++i)
		cout << '[' << orderArr[i] / pageSize << "]\t"
		<< orderArr[i] << endl;
	putchar('\n');

	LRU();
	return 0;
}

//初始化访问序列
void initInstrOrder(const int* srcArr, int size) {
	if (srcArr) {
		orderCnt = size;
		for (int i = 0; i < orderCnt; ++i) orderArr[i] = srcArr[i];
		return;
	}
	cout<<"ERROR: No order array specified!\n";
	return;
}

//输出页框状态
void showPageFrame(int timer[]) {
	cout << "pageFrame Stats:\n";
	int i;
	// 打印页框中的页号和内容, 还有页面停留的时间
	for (i = 0; i < cnt; ++i) {
		cout << "pageFrame:" << i + 1 << "\tPage:" << pageIdx[i] << "\t\tContent:";
		for (int j = 0; j < pageSize; ++j) {
			cout << pageFrame[i][j] << ' ';
		}
		cout << "\tTimer:" << timer[i];
		putchar('\n');
	}
	for (; i < pageFrameCnt; ++i) {
		cout << "pageFrame:" << i + 1 << "\tNONE\n";
	}
	putchar('\n');
}

//LRU
void LRU() {
	int timer[pageFrameCnt]; // 记录页框中页的未使用时间
	memset(timer, 0, sizeof(timer));
	for (int i = 0; i < orderCnt; ++i) {
		auto pageNo = orderArr[i] / pageSize;	//页号
		auto offset = orderArr[i] % pageSize;	//页内偏移

		cout << "now order: " << orderArr[i]
			<< "\tPage: " << pageNo
			<< "\tValue: " << processArr[orderArr[i]] << endl;

		int j;
		// 循环遍历页框若命中, 则将该页的未使用时间置0
		for (j = 0; j < cnt; ++j) {
			if (pageIdx[j] == pageNo) {
				cout << "cache hit " << pageFrame[j][offset] << endl;
				timer[j] = 0;
				break;
			}
		}
		// 若未命中
		if (j == cnt) {
			cout << "cache miss ";
			++pageMissCnt;	// 缺页次数+1

			// 若页框已全占满
			if (cnt == pageFrameCnt) {
				auto maxT = 0;

				//找到未使用时间最长的页框进行淘汰
				for (int k = 0; k < pageFrameCnt; ++k) {
					if (timer[k] > timer[maxT]) maxT = k;
				}
				copyFromTo(maxT, pageNo);
				timer[maxT] = 0;
				cout << pageFrame[maxT][offset] << endl;
			} else {
				// 页框未全部占满则直接将页复制到空页框
				copyFromTo(cnt, pageNo);
				cout << pageFrame[cnt][offset] << endl;
				++cnt;
			}
		}
		for (int j = 0; j < cnt; ++j) ++timer[j];
		showPageFrame(timer);
	}

	cout << "total access:" << orderCnt << " cache miss:" << pageMissCnt
		<< " LRU cache miss rate:" << float(pageMissCnt) / orderCnt *100 <<"%" << endl;
	return;
}


inline void copyFromTo(int pfIdx, int pageNo) {
	//复制数据
	memcpy(pageFrame[pfIdx],
		processArr + pageNo * pageSize, pageSize * sizeof(int));
	pageIdx[pfIdx] = pageNo;	//记录页号
}